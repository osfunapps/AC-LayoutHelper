import sys
import tinify


def launch_tiny_png(api_key, file_input_path, file_output_path):
    tinify.key = api_key
    source = tinify.tinify.from_file(file_input_path)
    source.to_file(file_output_path)
    counterStr = str(tinify.tinify.compression_count)
    print(counterStr + "/500 compressions made!")


if __name__ == '__main__':
    launch_tiny_png(sys.argv[1], sys.argv[2], sys.argv[3])
